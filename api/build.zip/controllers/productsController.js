const multer = require("multer");
const Product = require("../models/productSchema");
const fs = require("fs");

// Multer storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/products/"); // Set the destination folder for uploaded images
  },
  filename: function (req, file, cb) {
    // Generate a unique filename for each uploaded image
    const currentDateTime =  Date().now;
    const originalName = file.originalname.split(".")[0];
    const extension = file.originalname.split(".").pop();
    const uniqueFilename = `${originalName}_${currentDateTime}.${extension}`;
    cb(null, uniqueFilename);
  },
});

const upload = multer({ storage: storage });

const addProduct = async (req, res) => {
  const { name, description, price, discount, availability, category, offer } =
    req.body;

  console.log(req.body);

  try {
    // Check if the product already exists by name
    const existingProduct = await Product.findOne({ name });
    console.log("hello");

    if (existingProduct) {
      return res.status(400).send({ message: "Product already exists" });
    }

    // Get the filenames of the uploaded images
    const imageFiles = req.files.map((file) => file.filename);

    const newProduct = new Product({
      name,
      description,
      images: imageFiles,
      price,
      discount,
      availability,
      category: [],
    });

    if (offer) {
      newProduct.offer = offer;
    }

    // Push each category ID into the category array
    if (Array.isArray(category)) {
      newProduct.category = category;
    } else {
      newProduct.category.push(category);
    }

    const savedProduct = await newProduct.save();

    return res.status(200).send({
      message: "New product added successfully",
      data: savedProduct,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ message: "Failed to add a new product", error });
  }
};

const updateProduct = async (req, res) => {
  const productId = req.params.productId;
  const {
    name,
    description,
    price,
    discount,
    availability,
    highlight,
    category,
    offer,
  } = req.body;
  console.log(req.body, "files");
  const images = req.files.map((file) => file.filename);

  try {
    // Find the product by its ID
    const product = await Product.findById(productId);

    if (!product) {
      return res.status(404).send("Product not found");
    }

    // Update the product details
    product.name = name;
    product.description = description;
    product.price = price;
    product.discount = discount;
    product.availability = availability;
    product.category = category;
    product.highlight = highlight;
    if (offer !== "") {
      product.offer = offer;
    } else {
      product.offer = null;
    }

    // Update the product images
    product.images.push(...images);

    // Save the updated product
    const updatedProduct = await product.save();

    return res.status(200).send({
      message: "Product details updated successfully",
      data: updatedProduct,
    });
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .send({ message: "Failed to update product details" });
  }
};

// Controller function to delete a product
const deleteProduct = async (req, res) => {
  const productId = req.params.productId;
  console.log(productId);
  try {
    // Find the product by its ID
    const product = await Product.findById(productId);

    if (!product) {
      return res.status(404).send("Product not found");
    }
    console.log(product, "product");

    // Delete the product images from the file system
    for (const image of product.images) {
      fs.unlinkSync(`uploads/products/${image}`);
    }
    console.log("done");

    // Delete the product from the database
    const deletedproduct = await Product.findByIdAndDelete(productId);

    return res.status(200).send({
      message: "Product deleted successfully",
      data: deletedproduct,
    });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Failed to delete product", error: error });
  }
};

// get all products
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    return res.status(200).send(products);
  } catch (error) {
    return res.status(500).send({ message: "Failed to fetch products" });
  }
};

// get single product with reviews and categories
const getSingleProduct = async (req, res) => {
  const productId = req.params.productId;

  try {
    const product = await Product.findById(productId)
      .populate("reviews")
      .populate("category")
      .populate("offer");

    if (!product) {
      return res.status(404).send("Product not found");
    }

    return res.status(200).send(product);
  } catch (error) {
    return res.status(500).send({ message: "Failed to fetch product" });
  }
};

// add the product in highlighted products list
const highlight = async (req, res) => {
  const productId = req.params.productId;
  try {
    const product = await Product.findById(productId);

    if (!product) {
      return res.status(500).send("Product not found");
    }

    product.highlight = true;
    const updatedProduct = await product.save();

    return res.status(200).send({
      message: "Product added to highlighted list successfully",
      data: updatedProduct,
    });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Failed to add product to highlighted list", error });
  }
};

// add the product in highlighted products list
const removehighlight = async (req, res) => {
  const productId = req.params.productId;
  try {
    const product = await Product.findById(productId);

    if (!product) {
      return res.status(500).send("Product not found");
    }

    product.highlight = false;
    const updatedProduct = await product.save();

    return res.status(200).send({
      message: "Product removed from highlighted list successfully",
      data: updatedProduct,
    });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "Failed to add product to highlighted list", error });
  }
};

// get highlighted products (maximum 4nos)
const gethighlighted = async (Req, res) => {
  try {
    const highlighted = await Product.find({ highlight: true }).limit(4);

    if (highlighted.length === 0) {
      return res.status(500).send("No products found");
    }
    // console.log(highlighted, highlighted.length);
    return res
      .status(200)
      .send({ message: "Highlighted products", data: highlighted });
  } catch (error) {
    return res.status(500).send("failed to get the highlighted products");
  }
};

const deleteimg = async (req, res) => {
  const imageName = req.params.imageName;
  const productId = req.params.productid;
  console.log(req.params);

  try {
    // Find the product by its ID
    const product = await Product.findById(productId);
    console.log(product, "product");
    // Check if the product exists
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Remove the image from the images array
    product.images = product.images.filter((image) => image !== imageName);
    console.log(product.images, "images");
    // Save the updated product
    await product.save();
    console.log("saved");

    // Delete the image file
    fs.unlinkSync(`uploads/products/${imageName}`);

    res.status(200).json({ message: "Image deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to delete the image" });
  }
};

module.exports = {
  addProduct,
  upload,
  updateProduct,
  deleteProduct,
  getAllProducts,
  getSingleProduct,
  highlight,
  gethighlighted,
  removehighlight,
  deleteimg,
};

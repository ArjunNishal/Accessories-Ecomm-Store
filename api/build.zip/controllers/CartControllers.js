const Cart = require("../models/Cart");

const getCartItems = async (req, res) => {
  try {
    const userId = req.params.id;
    console.log(userId, "userid");
    const cartItems = await Cart.findOne({ user: userId }).populate(
      "items.product"
    );
    if (!cartItems || cartItems.length === 0) {
      return res.status(500).send("no cart found");
    }

    res.status(200).json(cartItems);
  } catch (error) {
    console.error("Error fetching cart items:", error);
    res.status(500).json({ error: "Server error" });
  }
};

const createCart = async (req, res) => {
  try {
    const { userId } = req.body;

    const newCart = new Cart({
      user: userId,
      items: [],
    });
    await newCart.save();

    res.status(200).json({ message: "Cart created successfully" });
  } catch (error) {
    console.error("Error creating cart:", error);
    res.status(500).json({ error: "Server error" });
  }
};

const addItemToCart = async (req, res) => {
  try {
    const { _id } = req.body;
    const userId = req.user;
    console.log(userId, _id, "item user id");
    // Check if the user already has a cart
    const cart = await Cart.findOne({ user: userId });

    if (!cart) {
      // If the user does not have a cart, create a new cart and add the item
      const newCart = new Cart({
        user: userId,
        items: [{ product: _id, quantity: 1 }],
      });
      const savedCart = await newCart.save();
      res.status(200).json(savedCart);
    } else {
      // If the user already has a cart, check if the item exists
      const existingItem = cart.items.find((item) => {
        console.log(
          item,
          "item ..................................................................................................................................."
        );
        return item.product.toString() === _id;
      });
      console.log(existingItem, "exists");
      if (existingItem) {
        // If the item exists, increase its quantity
        existingItem.quantity += 1;
      } else {
        // If the item does not exist, add it to the cart with a quantity of 1
        cart.items.push({ product: _id, quantity: 1 });
      }

      // Save the updated cart
      const updatedCart = await cart.save();
      console.log(updatedCart, "exists product");
      res.status(200).json(updatedCart);
    }
  } catch (error) {
    console.error("Error adding item to cart:", error);
    res.status(500).json({ error: "Server error" });
  }
};

const reduceItemInCart = async (req, res) => {
  try {
    const { _id } = req.body; // Assuming you receive the item ID in the request body
    const userId = req.user;
    console.log("this is running1");
    // Find the cart in the database
    const cart = await Cart.findOne({ user: userId });

    if (!cart) {
      return res.status(404).json({ error: "Cart not found" });
    }

    // Find the cart item to reduce its quantity
    const cartItem = cart.items.find((item) => item.product.toString() === _id);
    console.log("this is running2");
    if (!cartItem) {
      return res.status(404).json({ error: "Item not found in cart" });
    }

    if (cartItem.quantity === 1) {
      console.log("this is running3");
      // If the item's quantity is 1, remove it from the cart
      cart.items = cart.items.filter((item) => item.product.toString() !== _id);
    } else {
      console.log("this is running4");
      // If the item's quantity is greater than 1, reduce its quantity
      cartItem.quantity--;
    }

    // Save the updated cart
    await cart.save();

    res.status(200).json({ message: "Item reduced in cart successfully" });
  } catch (error) {
    console.error("Error reducing item in cart:", error);
    res.status(500).json({ error: "Server error" });
  }
};

const deleteItemFromCart = async (req, res) => {
  try {
    const { _id } = req.body;
    console.log(req.body, "req.body"); // Assuming you receive the user ID and item ID in the request body
    const userId = req.user;
    const itemId = _id;
    // Find the cart in the database
    const cart = await Cart.findOne({ user: userId });

    if (!cart) {
      return res.status(404).json({ error: "Cart not found" });
    }

    // Find the cart item to remove
    const cartItemIndex = cart.items.findIndex(
      (item) => item.product.toString() === itemId
    );

    if (cartItemIndex === -1) {
      return res.status(404).json({ error: "Item not found in cart" });
    }

    // Remove the cart item from the items array
    cart.items.splice(cartItemIndex, 1);

    // Save the updated cart
    await cart.save();

    res.status(200).json({ message: "Item deleted from cart successfully" });
  } catch (error) {
    console.error("Error deleting item from cart:", error);
    res.status(500).json({ error: "Server error" });
  }
};

const updatecart = async (req, res) => {
  try {
    const data = req.body;
    // console.log(data,"body");
    const cart = await Cart.findOne({ user: req.user }).populate(
      "items.product"
    );
    // console.log(cart,"cart", "car found in db");
    for (const cartitem of data) {
      // Check if the item already exists in the cart
      const existingItem = cart.items.find(
        (item) => item.product._id.toString() === cartitem._id
      );

      if (existingItem) {
        // Item already exists, update the quantity
        // console.log(existingItem, "existing items found");
        existingItem.quantity += cartitem.quantity;
      } else {
        // Item does not exist, add it to the cart
        cart.items.push({
          product: cartitem._id,
          quantity: cartitem.quantity,
        });
      }
    }
    // Save the updated cart
    const updatedCart = await cart.save();
    console.log(updatedCart, "updted cart");

    res.json({
      success: true,
      data: updatedCart,
      message: "Cart updated successfully",
    });
  } catch (error) {
    res.status(500).send(error);
  }
};

module.exports = {
  addItemToCart,
  reduceItemInCart,
  deleteItemFromCart,
  getCartItems,
  createCart,
  updatecart,
};

const Category = require("../models/categorySchema");
const multer = require("multer");
const Product = require("../models/productSchema");
const path = require("path");

// Multer configuration for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/category/"); // Specify the folder where uploaded images will be stored
  },
  filename: (req, file, cb) => {
    const originalName = file.originalname.split(".")[0];
    const ext = path.extname(file.originalname);
    const date = Date.now();
    const filename = `${originalName.replace(/\s/g, "")}_${date}${ext}`;
    cb(null, filename);
  },
});

const upload = multer({ storage });

// add category
const addCategory = async (req, res) => {
  const { name, priceRange } = req.body;
  const image = req.file ? req.file.path : "";

  try {
    const newCategory = new Category({
      name,
      image,
      priceRange,
    });

    const savedCategory = await newCategory.save();

    return res.status(200).send({
      message: "Category added successfully",
      data: savedCategory,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send({ message: "Failed to add category" });
  }
};

// get products of selected category
const getProductsByCategory = async (req, res) => {
  const category = req.params.category;
  console.log(category);
  try {
    const products = await Product.find({ category });
    if (products.length === 0) {
      return res.status(500).send({ message: " no products found" });
    }
    return res.status(200).send(products);
  } catch (error) {
    return res.status(500).send({ message: "Failed to fetch products" });
  }
};

const removecategory = async (req, res) => {
  const category = req.params.categoryId;

  if (!category) {
    return res.status(500).send("Category not found");
  }

  try {
    const categorymatch = await Category.findByIdAndDelete(category);

    return res.status(200).send({
      message: "Category deleted successfully",
      data: categorymatch,
    });
  } catch (error) {
    return res.status(500).send({ message: "Failed to delete category" });
  }
};

const getCategories = async (req, res) => {
  try {
    // Retrieve all categories from the database
    const categories = await Category.find();

    res.status(200).send(categories);
  } catch (error) {
    res.status(500).send({ message: "Failed to fetch categories" });
  }
};

module.exports = {
  addCategory,
  getProductsByCategory,
  removecategory,
  getCategories,
  upload,
};

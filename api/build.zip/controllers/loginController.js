const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("../models/usersSchema");
const Admin = require("../models/AdminSchema");
const otpGenerator = require("otp-generator");
const Otp = require("../models/otpSchema");
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "arjun.intoggle@gmail.com",
    pass: "rrqbfkgzzakdikno",
  },
});

const registerUser = async (req, res) => {
  const { username, email, password, mobileno } = req.body;
  console.log(req.body);
  // Check if user already exists
  const user = await User.findOne({
    $or: [{ email: email }, { mobileno: mobileno }, { username: username }],
  });

  if (user) {
    return res.status(400).send("User already exists");
  }

  // Hash the password
  const saltRounds = 10;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  // Create a new user
  const newUser = new User({
    username,
    email,
    mobileno,
    password: hashedPassword,
    isEmailVerified: false,
    isMobileVerified: false,
  });

  try {
    const savedUser = await newUser.save();

    // Generate OTP
    const OTP = otpGenerator.generate(6, {
      upperCaseAlphabets: false,
      specialChars: false,
      lowerCaseAlphabets: false,
    });

    // Hash the OTP
    const salt = await bcrypt.genSalt(10);
    const hashedOTP = await bcrypt.hash(OTP, salt);

    // Create OTP entry
    const otp = new Otp({ recipient: email, code: hashedOTP });
    const otpResult = await otp.save();

    // Send email to the user
    const mailOptions = {
      from: "arjun.intoggle@gmail.com",
      to: email,
      subject: "Email Verification",
      text: `Your OTP for email verification is: ${OTP}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log("Email sending failed:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });

    // Generate token
    const token = jwt.sign({ id: savedUser._id }, process.env.JWT_SECRET_KEY);

    return res.status(200).send({
      message: "User registered successfully",
      token: token,
      data: savedUser,
    });
  } catch (error) {
    return res.status(500).send({ message: "User registration failed" });
  }
};

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if user exists with the given email
    let user = await Admin.findOne({ email });

    if (!user) {
      user = await User.findOne({ email });

      if (!user) {
        return res.status(404).send("User not found");
      }
    }

    if (!user) {
      return res.status(404).send("User not found");
    }

    // Compare the provided password with the hashed password
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).send("Invalid password");
    }

    // Generate token
    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET_KEY);

    return res.status(200).send({
      message: "User logged in successfully",
      token: token,
      data: user,
    });
  } catch (error) {
    return res.status(500).send({ message: "Login failed" });
  }
};

const requestEmailOtp = async (req, res) => {
  const { email, code } = req.body;

  try {
    const otpholder = await Otp.find({ recipient: email });

    if (otpholder.length === 0) {
      return res.status(500).send("OTP expired or incorrect");
    }

    const rightOtpFind = otpholder[otpholder.length - 1];
    const validOTP = await bcrypt.compare(code, rightOtpFind.code);

    if (rightOtpFind.recipient === email && validOTP) {
      // Find the user by email
      const user = await User.findOne({ email });

      if (!user) {
        return res.status(404).send("User not found");
      }

      // Update the user's email verification status
      user.isEmailVerified = true;

      // Save the updated user
      const savedUser = await user.save();

      // Delete the OTP entry
      await Otp.deleteMany({ recipient: rightOtpFind.email });

      // Generate token
      const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET_KEY);

      return res.status(200).send({
        message: "Email verification successful",
        token: token,
        data: savedUser,
      });
    } else {
      return res.status(500).send({ message: "Email verification failed" });
    }
  } catch (error) {
    return res.status(500).send({ message: "Email verification failed" });
  }
};

const verifyMobileOtp = async (req, res) => {
  const { mobileno, code } = req.body;

  // Check if the received OTP matches the fixed value "1234"
  if (code !== "1234") {
    return res.status(500).send("Invalid OTP");
  }

  try {
    // Find the user by mobileno
    const user = await User.findOne({ mobileno });

    if (!user) {
      return res.status(404).send("User not found");
    }

    user.isMobileVerified = true;
    const savedUser = await user.save();

    return res.status(200).send({
      message: "User registration verified successfully",
      data: savedUser,
    });
  } catch (error) {
    return res
      .status(500)
      .send({ message: "User registration verification failed" });
  }
};

const verifyEmail = async (req, res) => {
  const { email } = req.body;

  try {
    // Check if user exists with the given email
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(500).send({ message: "Email does not exist" });
    }

    // Generate OTP
    const OTP = otpGenerator.generate(6, {
      upperCaseAlphabets: false,
      specialChars: false,
      lowerCaseAlphabets: false,
    });

    // Hash the OTP
    const salt = await bcrypt.genSalt(10);
    const hashedOTP = await bcrypt.hash(OTP, salt);

    const otp = new Otp({ recipient: email, code: hashedOTP });
    const otpResult = await otp.save();

    // Send mail to user
    const mailOptions = {
      from: "arjun.intoggle@gmail.com",
      to: email,
      subject: "Email Verification",
      text: `Your OTP for email verification is: ${OTP}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.log("Email sending failed:", error);
      } else {
        console.log("Email sent:", info.response);
      }
    });

    return res.status(200).send({
      message: "OTP sent to email for login",
      data: email,
    });
  } catch (error) {
    return res.status(500).send({ message: "OTP request failed" });
  }
};

const forgotpassword = async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.send("We cannot find your email.");
    }
    const secret = process.env.JWT_SECRET_KEY;
    const token = jwt.sign({ email: user.email, id: user.id }, secret, {
      expiresIn: "5m",
    });
    const link = `http://localhost:8000/api/user/resetpassword/${user.id}/${token}`;
    const link2 = `http://localhost:3000/resetpassword/${user.id}/${token}`;
    console.log(link, link2, "================= link ============= ");
    // save the token in the database along with the user id and an expiration date
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 3600000; // 1 hour

    await user.save();

    // send the password reset email
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "arjun.intoggle@gmail.com",
        pass: "rrqbfkgzzakdikno",
      },
    });

    const mailOptions = {
      from: "arjun.intoggle@gmail.com",
      to: email,
      subject: "Password Reset",
      text: `You are receiving this because you (or someone else) has requested the reset of the password for your account. Please click on the following link, or paste this into your browser to complete the process:\n\n
    http://localhost:3000/resetpassword/${user.id}/${token} \n\n
      If you did not request this, please ignore this email and your password will remain unchanged.\n`,
    };

    transporter.sendMail(mailOptions, (err, info) => {
      if (err) {
        console.log(err);
        return res.status(500).json({ message: "Failed to send email" });
      }
      console.log(`Email sent to ${email}: ${info.response}`);
      return res.json({ message: "Email sent successfully" });
    });
  } catch (error) {
    console.log(error, "error");
  }
};

const resetpass =  async (req, res) => {
  const { id, token } = req.params;
  const { password ,confirmPassword } = req.body;
  console.log(password)

  try {
    const user = await User.findById(id);
    if (!user) {
      return res.status(500).send("Invalid user ID");
    }
    if (password.includes(" ")) {
      return res
        .status(500)
        .json({ message: "Password should not have spaces." });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET_KEY);
    if (decodedToken.id !== user.id) {
      return res.status(500).send("Invalid token");
    }
    // Hash the password before saving
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    user.password = hashedPassword;
    await user.save();

    res.send("Password reset successfully");
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
}

module.exports = {
  forgotpassword,
  registerUser,
  resetpass,
  loginUser,
  requestEmailOtp,
  verifyMobileOtp,
  verifyEmail,
};

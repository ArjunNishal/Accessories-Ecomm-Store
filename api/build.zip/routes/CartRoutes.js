const cartController = require("../controllers/CartControllers");
const express = require("express");
const router = express.Router();

router.get("/getcart/:id", cartController.getCartItems);
router.post("/add", cartController.addItemToCart);
router.post("/reduce", cartController.reduceItemInCart);
router.post("/delete", cartController.deleteItemFromCart);
router.post("/createcart", cartController.createCart);
router.post("/update", cartController.updatecart);

module.exports = router;

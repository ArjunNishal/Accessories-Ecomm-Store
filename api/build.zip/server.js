const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
const Loginroutes = require("./routes/loginRoutes");
const Productroutes = require("./routes/productsRoutes");
const Categoryroutes = require("./routes/categoryRoutes");
const favitemroutes = require("./routes/FavitemRoutes");
const reviewroutes = require("./routes/ReviewRoutes");
const offerroutes = require("./routes/OfferRoutes");
const couponroutes = require("./routes/couponsRoutes");
const adminRoutes = require("./routes/adminRoutes");
const CartRoutes = require("./routes/CartRoutes");
const authenticate = require("./Middlewares/auth");

require("dotenv").config();
app.use(cors({ credentials: true, origin: "http://localhost:3000" }));
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use("/uploads", express.static("./uploads"));

// ROUTES
app.use("/api/user", Loginroutes);
app.use("/api/product", Productroutes);
app.use("/api/category", Categoryroutes);
app.use("/api/favitem", authenticate, favitemroutes);
app.use("/api/review", authenticate, reviewroutes);
app.use("/api/offer", authenticate, offerroutes);
app.use("/api/coupon", authenticate, couponroutes);
app.use("/api/admin", authenticate, adminRoutes);
app.use("/api/cart", authenticate, CartRoutes);

//db connection
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(console.log("connected to mongo"))
  .catch((err) => console.log(err));

app.listen(process.env.PORT, () =>
  console.log(`Example app listening on port ${process.env.PORT}!`)
);

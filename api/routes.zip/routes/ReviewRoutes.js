const express = require("express");
const router = express.Router();
const addReviewController = require("../controllers/ReviewControllers");

// Add a new review
router.post(
  "/addreview",
  addReviewController.upload.array("image", 5),
  addReviewController.addReview
);

router.delete("/removereview/:reviewId", addReviewController.removeReview);

module.exports = router;

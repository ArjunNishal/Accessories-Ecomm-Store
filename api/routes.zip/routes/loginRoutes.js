const express = require("express");
const router = express.Router();
const loginController = require("../controllers/loginController");

const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "arjun.intoggle@gmail.com",
    pass: "rrqbfkgzzakdikno",
  },
});

router.post("/signup", loginController.registerUser);
router.post("/login", loginController.loginUser);
router.post("/otp/email/req", loginController.requestEmailOtp);
router.post("/verify/email", loginController.verifyEmail);
router.post("/verify/mobile", loginController.verifyMobileOtp);
// forgot password
// send reset pass link to mail =================================================
router.post("/resetpassword", loginController.forgotpassword);

// reset passsword =================================================================
router.put("/resetpassword/:id/:token",loginController.resetpass);

module.exports = router;

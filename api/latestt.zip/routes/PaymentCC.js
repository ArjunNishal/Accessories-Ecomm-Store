// const express = require("express");
// const router = express.Router();
// const crypto = require("crypto");
// const axios = require("axios");
// const Order = require("../models/OrderSchema");
// const constants = require("../constants");

// router.post("/gateway", async (req, res) => {
//   const { getdata, orderId } = req.body;
//   console.log(req.body);
//   var db = JSON.stringify(orderId);
//   var orderid = JSON.parse(db);
//   const discountAmt = await Order.findById(orderid).select("ordertotal");

//   const amount = discountAmt.ordertotal;
//   const currency = "INR";

//   const accessCode = "AVYP16KI36CC98PYCC";
//   const merchantId = "2786832";
//   const encryptionKey = "A6452BC29B9EED2575538AEECFC591C1";
//   const order_id = discountAmt._id.toString();
//   const redirect_url = `${constants.frontUrl}order/success?session_id={CHECKOUT_SESSION_ID}&order_id=${order_id}`;
//   const cancel_url = `${constants.frontUrl}cart`;
//   const language = "eng";
//   // Extract payment data from the request
//   //   const { order_id, amount, currency, redirect_url, cancel_url, language } =
//   //     req.body;

//   // Create a data string for generating checksum
//   const data = `${accessCode}|${order_id}|${amount}|${currency}|${redirect_url}|${cancel_url}|${language}`;

//   // Generate a checksum using SHA-256
//   const checksum = crypto
//     .createHmac("sha256", encryptionKey)
//     .update(data)
//     .digest("hex");

//   // Send a request to CCAvenue for payment
//   try {
//     const response = await axios.post(
//       "https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction",
//       {
//         access_code: accessCode,
//         order_id,
//         amount,
//         currency,
//         redirect_url,
//         cancel_url,
//         language,
//         checksum,
//       }
//     );
//     console.log(
//       response.data,
//       "==========response ================================"
//     );
//     res
//       .status(200)
//       .json({
//         data: response.data,
//         redirect_url: redirect_url,
//         cancel_url: cancel_url,
//       });
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: "Payment request failed" });
//   }
// });
// module.exports = router;

const express = require("express");
const router = express.Router();
const crypto = require("crypto");
const axios = require("axios");
const Order = require("../models/OrderSchema");
const constants = require("../constants");

router.post("/gateway", async (req, res) => {
  const { getdata, orderId } = req.body;
  console.log(req.body);
  var db = JSON.stringify(orderId);
  var orderid = JSON.parse(db);
  const discountAmt = await Order.findById(orderid).populate("user");
  console.log(discountAmt, orderid);

  const amount = discountAmt.ordertotal;
  const currency = "INR";

  const accessCode = "AVYP16KI36CC98PYCC";
  const merchantId = "2786832";
  const encryptionKey = "A6452BC29B9EED2575538AEECFC591C1";
  const order_id = discountAmt._id.toString();
  const redirect_url = `${constants.frontUrl}order/success?session_id={CHECKOUT_SESSION_ID}&order_id=${order_id}`;
  const cancel_url = `${constants.frontUrl}cart`;
  const language = "eng";
  // Extract payment data from the request
  //   const { order_id, amount, currency, redirect_url, cancel_url, language } =
  //     req.body;

  // Create a data string for generating checksum
  // const data = `${accessCode}|${order_id}|${amount}|${currency}|${redirect_url}|${cancel_url}|${language}`;

  // Generate a checksum using SHA-256
  // const checksum = crypto
  //   .createHmac("sha256", encryptionKey)
  //   .update(data)
  //   .digest("hex");

  // Send a request to CCAvenue for payment

  console.log(
    typeof amount,
    amount,
    "amount is this =================================="
  );
  try {
    var clientTxnId =
      new Date().getTime().toString() + Math.floor(Math.random() * 1000);
    console.log(
      typeof discountAmt.mobileno,
      discountAmt.mobileno,
      "=== mobileno ||"
    );
    const redirecturl = `https://customizehere.in/order/success?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`;
    // const redirecturl = `${constants.frontUrl}order/success?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`;
    console.log(
      typeof redirecturl,
      redirecturl,
      "redirecturl ==================="
    );
    var data = JSON.stringify({
      key: "4c705bc6-cdbc-4963-88ab-93f0c1bfb79f",
      client_txn_id: clientTxnId,
      amount: amount,
      p_info: "Product Name",
      customer_name: discountAmt?.user?.username
        ? discountAmt.user.username
        : discountAmt.firstName,
      customer_email: discountAmt.email,
      customer_mobile: discountAmt.phone,
      redirect_url: redirecturl,
      udf1: "user defined field 1",
      udf2: "user defined field 2",
      udf3: "user defined field 3",
    });

    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://api.ekqr.in/api/create_order",
      headers: {
        "Content-Type": "application/json",
      },
      data: data,
    };

    let responsepay = {};

    axios(config)
      .then(function (response) {
        console.log(response);
        console.log(JSON.stringify(response.data), "response========");
        // console.log(response, "payment");
        responsepay = response.data;
        res.status(200).json({
          // data: data,
          // checksum: checksum,
          status: true,
          data: response.data,
          // redirect_url: redirect_url,
          // cancel_url: cancel_url,
          // language: language,
          // access_code: accessCode,
          // order_id: order_id,
          // amount: amount,
          // currency: currency,
          // encryptionKey: encryptionKey,
          // order: discountAmt,
        });
      })
      .catch(function (error) {
        console.log(error, "error in payment");
      });

    // const response = await axios.post(
    //   "https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction",
    //   {
    //     access_code: accessCode,
    //     order_id,
    //     amount,
    //     currency,
    //     redirect_url,
    //     cancel_url,
    //     language,
    //     checksum,
    //   }
    // );
    // console.log(
    //   response.data,
    //   "==========response ================================"
    // );

    console.log(responsepay, "responsepay");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Payment request failed" });
  }
});

// stripe
// const stripe = require("stripe")(
//   "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"
// );
const stripe = require("stripe")(
  "sk_test_51NPirUSGPN3Ia4GzonG7mYLT5S9wie851xXChWnOpJz4iHBNFhaqjRer9oAN9DOD3LtKSfr8HHyHzkc7sGde4Nae00IQHQBeJN"
);

router.post("/gateway/stripe", async (req, res) => {
  try {
    const { getdata, orderId } = req.body;
    console.log("req.params.orderId", orderId);
    // console.log("req.params.getdat", getdata);
    // const discountAmount = Order.findById(req.params.orderId).select('appliedCoupon');
    // console.log(type(req.params.orderId));
    // console.log(typeof(JSON.parse(orderId)));
    var db = JSON.stringify(orderId);
    var orderid = JSON.parse(db);
    const discountAmt = await Order.findById(orderid).select("ordertotal");
    // console.log("discountAmount", discountAmt.appliedCoupon.discountedPrice);
    // const T = discountAmt.appliedCoupon.code;
    const TotalAmount = discountAmt.ordertotal;
    // console.log("discountAmount price", discountAmount.discountedPrice);
    // const TotalDiscount = discountAmount.
    // console.log(process.env.STRIPE_SECRET_KEY);
    // getdata.push({name:Coupon, price:Math.ceil(-CouponAmt), discount:Math.ceil(-CouponAmt), quantity:1});
    console.log("getdata", getdata);

    const mydata = [{ name: "Total Amount", price: TotalAmount, quantity: 1 }];

    const lineItems = mydata.map((product) => ({
      price_data: {
        currency: "inr",
        product_data: {
          name: product.name,
        },
        unit_amount: product.price * 100,
      },
      quantity: product.quantity,
    }));

    console.log(lineItems);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: lineItems,
      mode: "payment",
      success_url: `${constants.frontUrl}order/success?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`,
      cancel_url: `${constants.frontUrl}cart`,
    });
    console.log(session, "session");
    res.status(200).json({ session });
  } catch (error) {
    console.error("Error creating Stripe checkout session:", error);
    res.status(500).json({ error });
  }
});

module.exports = router;
